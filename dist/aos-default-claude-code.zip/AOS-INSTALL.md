# AOS (default) for claude-code

Unzip at the ROOT of your project (merge into existing folders). It adds `.claude/` and a marked AOS block in AGENTS.md / CLAUDE.md, plus `.aos/` in .gitignore.

Claude Code: skills, agents and slash commands load automatically (/aos-optimize, /aos-route, ...). Delegation: `claude --agent orchestrator`.
Runtime scripts: `python3 .claude/aos/scripts/<name>.py --help` (Python 3.9+, standard library only).
