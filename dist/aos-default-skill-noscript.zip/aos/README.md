# AOS skill (default, script-free)

Install: Claude Code `~/.claude/skills/aos/` (or `<project>/.claude/skills/aos/`); Codex `~/.codex/skills/aos/`; claude.ai: upload this folder as a skill (Settings > Capabilities > Skills).
Entry point: SKILL.md. Honest limits: routing is uncalibrated; savings are unmeasured (docs/BENCHMARKS.md).
