Use the aos-omega skill and the omega agent method for this goal: $ARGUMENTS
Resume from `omega.py status` if state exists; otherwise initialize it. Do not wait for approval on routine work; queue guarded actions and continue.
