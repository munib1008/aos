# AOS (dormakaba) for codex

Unzip at the ROOT of your project (merge into existing folders). It adds `.codex/` and a marked AOS block in AGENTS.md, plus `.aos/` in .gitignore.

Codex: skills in `.codex/skills`, agents in `.codex/agents/*.toml`, instructions via AGENTS.md. Verify your Codex version loads them (docs/COMPATIBILITY.md).
Runtime scripts: `python3 .codex/aos/scripts/<name>.py --help` (Python 3.9+, standard library only).
