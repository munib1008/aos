---
name: aos
description: Adaptive Optimization System for AI-assisted development at dormakaba. Use when starting or planning a software, automation, research or video task and you want the right complexity level, model tier, skills, minimal context, verified project memory and a policy-checked, redacted handoff. Script-free: all steps are written procedures.
---
# AOS (dormakaba build) (script-free)

Provider-independent workflow layer. It recommends; it never switches models or sends data anywhere. This package contains no executable code: every step is a written procedure in `procedures.md` that you carry out with normal file, search and shell tools.

## Flow
1. **Memory first** (P1). Search project memory; answer from verified entries before scanning code.
2. **Route** (P2). Score the 8 dimensions, derive level 1-4, then model tier and effort from `config/models.yaml`. Scores are judgment, not calibrated. Level 4 or any destructive, production or policy step needs explicit human approval.
3. **Select skills** (P3). Read at most three module files below.
4. **Minimal context** (P4, P9). Search first, read ranges, stop when answerable.
5. **Implement and verify** (P5). Smallest correct change; report PASSED, FAILED or NOT VERIFIED honestly.
6. **Learn** (P1, P11). Store only source-backed facts.
7. **Long sessions** (P6, P7). Compact within one workstream, fork with git worktrees for independent ones, hand off with redaction.
8. **Policy check** (P8) before delivering.

Read `procedures.md` for the steps and thresholds.

## Modules (read on demand, one at a time)
- Core: `modules/skills/aos-context.md`, `modules/skills/aos-handoff.md`, `modules/skills/aos-learning.md`, `modules/skills/aos-optimize.md`, `modules/skills/aos-repo-scan.md`, `modules/skills/aos-session-fork.md`, `modules/skills/aos-task-router.md`, `modules/skills/aos-validation.md`
- Specialist: `modules/skills/aos-ai-ml.md`, `modules/skills/aos-api-development.md`, `modules/skills/aos-automation.md`, `modules/skills/aos-database.md`, `modules/skills/aos-research.md`, `modules/skills/aos-security-review.md`, `modules/skills/aos-ui-ux.md`, `modules/skills/aos-video.md`
- Companion: `modules/skills/model-advisor.md`, `modules/skills/humanizer.md`
- Agent roles: `modules/agents/` (orchestrator, router, navigator, context-optimizer, session-manager, handoff, learning, testing, minimal-change)
- Slash-command prompts: `modules/commands/`

## dormakaba rules (non-negotiable)
- Models: only the AI Platform catalog in `config/models.yaml`; the user picks the model in the picker.
- Removed: credits registry, free-tier or personal API keys, local model runtimes, automatic model switching, external media-generation APIs.
- Never store or echo passwords, tokens, key system numbers or codes, card codes, TAN codes, security answers.
- Handoff only to AI Platform models or IT-approved enterprise accounts. Write "dormakaba" in lowercase.

## Honest limits
Routing is judgment-based and uncalibrated; cost savings are unmeasured; nothing here enforces policy automatically, so apply P8 yourself.
