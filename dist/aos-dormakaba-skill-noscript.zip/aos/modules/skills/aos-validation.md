<!-- aos-validation: Validate changes and the AOS system itself - focused tests, regression checks, honest test summaries, memory validation, and baseline-vs-AOS efficiency audit. Use after code changes and for /aos-audit -->
# aos-validation
**Code**: (procedure P5 in procedures.md) (risk flags) -> (procedure P5 in procedures.md). Order: affected tests, type/lint, broader regression for shared/auth/data/migration changes. Report PASSED / FAILED / NOT VERIFIED; unparsed non-zero exit is FAILED.
**Quality gate**: acceptance criteria met, critical tests pass, no new unauthorized access, no data loss, maintainable, no regression.
**Memory**: (procedure P1 in procedures.md).
**AOS self-test**: `python3 -m unittest discover -s aos/tests`.
**Audit (/aos-audit)**: `measure_usage.py transcript --latest` for real usage; `measure_usage.py record ...` per benchmark run (baseline vs aos); `measure_usage.py compare`. Report only measured numbers; verdict REJECT when pass rate or regressions worsen. See docs/BENCHMARKS.md.
